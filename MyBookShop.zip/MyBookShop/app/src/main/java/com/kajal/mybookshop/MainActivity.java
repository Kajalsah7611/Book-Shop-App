package com.kajal.mybookshop;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import com.kajal.mybookshop.Common;
import com.kajal.mybookshop.R;
import com.kajal.mybookshop.RecyclerAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<Common> CommonList;
    RecyclerView recyclerView;
    RecyclerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CommonList=new ArrayList<>();
        CommonList.add(new Common("Five Point Someone","Novel","Young india","Rs. 212","Chetan Bhagat","https://www.amazon.in/gp/product/8129135493/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=kajalsah7611-21&creative=24630&linkCode=as2&creativeASIN=8129135493&linkId=8ba4b0f469fbb1da96806619c732e3fa",R.drawable.fivepoint));
        CommonList.add(new Common("Half Girlfriend","Novel","young generation","Rs.199","Chetan Bhagat","https://www.amazon.in/gp/product/B013VO02LS/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=kajalsah7611-21&creative=24630&linkCode=as2&creativeASIN=B013VO02LS&linkId=3a0a333cfe8b60257b7f3a9e751c94f7",R.drawable.half));
        CommonList.add(new Common("Revolution 2020","Novel","Young india","Rs. 212","Chetan Bhagat","https://amzn.to/3tkzN1R",R.drawable.revolution));
        CommonList.add(new Common("Oh Yes","Novel","young generation","Rs.199","Chetan Bhagat","https://amzn.to/2MhC4un",R.drawable.ohyes));
        CommonList.add(new Common("The girl","Novel","Young india","Rs. 212","Chetan Bhagat","https://amzn.to/3tizPY6",R.drawable.thegirl));
        CommonList.add(new Common("Two states","Novel","young generation","Rs.138","Chetan Bhagat","https://amzn.to/2MruMnJ",R.drawable.twostates));
        CommonList.add(new Common("What young india wants","Novel","Young india","Rs. 91","Chetan Bhagat","https://amzn.to/36zVph9",R.drawable.what));
        CommonList.add(new Common("World best boyfriend ","Novel","young generation","Rs.149","Durjoy Dutta","https://amzn.to/3j9nxfY",R.drawable.world));
        CommonList.add(new Common("The 3 Mistakes Of My Life","Novel","young generation","Rs.146","Chetan Bhagat","https://amzn.to/3apGO9h",R.drawable.mistakes));
        CommonList.add(new Common("One Arranged Murder","Novel","young generation","Rs.128","Chetan Bhagat","https://amzn.to/36AYwoX",R.drawable.murder));

        CommonList.add(new Common("kai Po Che","Novel","Young india","Rs. 212","Chetan Bhagat","",R.drawable.kaipo));
        CommonList.add(new Common("Second To Nun","Novel","young generation","Rs.199","Chetan Bhagat","",R.drawable.second));
        CommonList.add(new Common("One Indian Girl","Novel","Young india","Rs. 212","Chetan Bhagat","",R.drawable.download));
        CommonList.add(new Common("Making India Awesome","Novel","young generation","Rs.199","Chetan Bhagat","",R.drawable.making));
        CommonList.add(new Common("5 Point Someone","Novel","Young india","Rs. 212","Chetan Bhagat","",R.drawable.images));
        CommonList.add(new Common("The 3 Mistakes Of My Life","Novel","young generation","Rs.146","Chetan Bhagat","https://amzn.to/3apGO9h",R.drawable.mistakes));
        CommonList.add(new Common("India Positive","Novel","Young india","Rs. 212","Chetan Bhagat","",R.drawable.positive));
        CommonList.add(new Common("One Arranged Murder","Novel","young generation","Rs.199","Chetan Bhagat","",R.drawable.murder));
        CommonList.add(new Common("Love & Marriage","Novel","Young india","Rs. 212","Chetan Bhagat","",R.drawable.love));
        CommonList.add(new Common("One Night At The Call Centre","Novel","young generation","Rs.199","Chetan Bhagat","",R.drawable.call));

        recyclerView=findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        adapter=new RecyclerAdapter(this,CommonList);
        recyclerView.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }
}

