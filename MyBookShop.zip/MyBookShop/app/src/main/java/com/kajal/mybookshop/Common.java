package com.kajal.mybookshop;

public class Common {
    
    String title,category,des,price,author,link;
    int image;
    //use shift+fn+insert key to create getter and setter and select all elements,this will create all below codes
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }


    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    //use shift+fn+insert key to create constructor and select all elements, this will create all below lines
    public Common(String title, String category, String des, String price, String author,String link, int image) {
        this.title = title;
        this.category = category;
        this.des = des;
        this.price = price;
        this.author = author;
        this.link=link;
        this.image = image;
    }
}









