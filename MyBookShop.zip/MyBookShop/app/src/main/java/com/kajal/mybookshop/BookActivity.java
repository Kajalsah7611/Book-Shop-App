package com.kajal.mybookshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class BookActivity extends AppCompatActivity {
    ImageView image;
    TextView title,price,author,cat,about;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);
        image=findViewById(R.id.img);
        title=findViewById(R.id.text2);
        price=findViewById(R.id.price);
        author=findViewById(R.id.author);
        cat=findViewById(R.id.category);
        about=findViewById(R.id.about);
        button=findViewById(R.id.buy);
        String titles=getIntent().getExtras().getString("title");
        int img=getIntent().getExtras().getInt("img");
        String prices=getIntent().getExtras().getString("price");
        String authors=getIntent().getExtras().getString("author");
        String cats=getIntent().getExtras().getString("cat");
        String des=getIntent().getExtras().getString("des");
        String link=getIntent().getExtras().getString("link");
        image.setImageResource(img);
        title.setText(titles);
        price.setText(prices);
        author.setText(authors);
        cat.setText(cats);
        about.setText(des);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(link));
                startActivity(intent);
            }
        });

    }
}